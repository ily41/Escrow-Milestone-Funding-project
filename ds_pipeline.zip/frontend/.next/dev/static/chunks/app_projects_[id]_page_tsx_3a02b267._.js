(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_517574b4._.js",
  "static/chunks/node_modules_date-fns_a5cdb082._.js"
],
    source: "dynamic"
});
