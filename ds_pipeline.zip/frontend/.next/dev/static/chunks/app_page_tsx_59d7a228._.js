(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_fefc4ac1._.js",
  "static/chunks/_8b1e8f5a._.js"
],
    source: "dynamic"
});
