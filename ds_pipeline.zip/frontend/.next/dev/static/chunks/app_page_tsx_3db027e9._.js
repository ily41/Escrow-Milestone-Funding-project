(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1854ea7f._.js",
  "static/chunks/node_modules_gsap_f48a6384._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_fdd5ade6._.js",
  "static/chunks/node_modules_7e0b80a2._.js"
],
    source: "dynamic"
});
