(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__cf97ae8d._.css",
  "static/chunks/node_modules_033ff878._.js",
  "static/chunks/_9d4d8bcd._.js"
],
    source: "dynamic"
});
