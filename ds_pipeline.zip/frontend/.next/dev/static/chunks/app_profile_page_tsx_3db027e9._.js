(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c6825a72._.js",
  "static/chunks/_4ddfbfc9._.js"
],
    source: "dynamic"
});
