var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/node_modules_next_490e64f3._.js")
R.c("server/chunks/[root-of-the-server]__c2ab6205._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_9118e90f.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/robots--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/robots--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
