module.exports = [
"[project]/.next-internal/server/app/auth/register/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_auth_register_page_actions_461674e2.js.map