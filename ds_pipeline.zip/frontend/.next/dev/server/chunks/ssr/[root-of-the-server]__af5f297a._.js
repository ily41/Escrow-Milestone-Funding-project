module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/lib/api.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API client for communicating with Django backend
 */ __turbopack_context__.s([
    "activateProject",
    ()=>activateProject,
    "createMilestone",
    ()=>createMilestone,
    "createPledge",
    ()=>createPledge,
    "createProject",
    ()=>createProject,
    "createRefund",
    ()=>createRefund,
    "createUpdate",
    ()=>createUpdate,
    "createVote",
    ()=>createVote,
    "deactivateProject",
    ()=>deactivateProject,
    "getCurrentUser",
    ()=>getCurrentUser,
    "getMilestones",
    ()=>getMilestones,
    "getMyProjects",
    ()=>getMyProjects,
    "getPledges",
    ()=>getPledges,
    "getProject",
    ()=>getProject,
    "getProjectStats",
    ()=>getProjectStats,
    "getProjects",
    ()=>getProjects,
    "getRefunds",
    ()=>getRefunds,
    "getUpdates",
    ()=>getUpdates,
    "getVotes",
    ()=>getVotes,
    "getWallets",
    ()=>getWallets,
    "login",
    ()=>login,
    "openVoting",
    ()=>openVoting,
    "register",
    ()=>register,
    "releaseFunds",
    ()=>releaseFunds
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-rsc] (ecmascript)");
;
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';
// Create axios instance
const apiClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});
// Add token to requests if available
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const login = async (username, password)=>{
    const response = await apiClient.post('/token/', {
        username,
        password
    });
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return response.data;
};
const register = async (data)=>{
    const response = await apiClient.post('/users/register/', data);
    return response.data;
};
const getCurrentUser = async ()=>{
    const response = await apiClient.get('/users/me/');
    return response.data;
};
const getProjects = async (params)=>{
    const response = await apiClient.get('/projects/', {
        params
    });
    return response.data.results || response.data;
};
const getProject = async (id)=>{
    const response = await apiClient.get(`/projects/${id}/`);
    return response.data;
};
const createProject = async (data)=>{
    const response = await apiClient.post('/projects/', data);
    return response.data;
};
const activateProject = async (id)=>{
    const response = await apiClient.post(`/projects/${id}/activate/`);
    return response.data;
};
const deactivateProject = async (id)=>{
    const response = await apiClient.post(`/projects/${id}/deactivate/`);
    return response.data;
};
const getProjectStats = async (id)=>{
    const response = await apiClient.get(`/projects/${id}/stats/`);
    return response.data;
};
const getMyProjects = async ()=>{
    const response = await apiClient.get('/projects/my_projects/');
    return response.data;
};
const getMilestones = async (projectId)=>{
    const params = projectId ? {
        project: projectId
    } : {};
    const response = await apiClient.get('/projects/milestones/', {
        params
    });
    return response.data.results || response.data;
};
const createMilestone = async (data)=>{
    const response = await apiClient.post('/projects/milestones/', data);
    return response.data;
};
const openVoting = async (milestoneId)=>{
    const response = await apiClient.post(`/projects/milestones/${milestoneId}/open_voting/`);
    return response.data;
};
const createPledge = async (projectId, data)=>{
    const response = await apiClient.post(`/projects/${projectId}/pledge/`, data);
    return response.data;
};
const getPledges = async (projectId)=>{
    const params = projectId ? {
        project: projectId
    } : {};
    const response = await apiClient.get('/finance/pledges/', {
        params
    });
    return response.data.results || response.data;
};
const createVote = async (data)=>{
    const response = await apiClient.post('/governance/votes/', data);
    return response.data;
};
const getVotes = async (milestoneId)=>{
    const params = milestoneId ? {
        milestone: milestoneId
    } : {};
    const response = await apiClient.get('/governance/votes/', {
        params
    });
    return response.data.results || response.data;
};
const releaseFunds = async (milestoneId)=>{
    const response = await apiClient.post(`/finance/releases/milestone/${milestoneId}/`);
    return response.data;
};
const createRefund = async (data)=>{
    const response = await apiClient.post('/finance/refunds/', data);
    return response.data;
};
const getRefunds = async ()=>{
    const response = await apiClient.get('/finance/refunds/');
    return response.data.results || response.data;
};
const getWallets = async ()=>{
    const response = await apiClient.get('/finance/wallets/');
    return response.data.results || response.data;
};
const getUpdates = async (projectId)=>{
    const params = projectId ? {
        project: projectId
    } : {};
    const response = await apiClient.get('/projects/updates/', {
        params
    });
    return response.data.results || response.data;
};
const createUpdate = async (data)=>{
    const response = await apiClient.post('/projects/updates/', data);
    return response.data;
};
}),
"[project]/components/ProjectDetail.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/ProjectDetail.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/ProjectDetail.tsx <module evaluation>", "default");
}),
"[project]/components/ProjectDetail.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/ProjectDetail.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/ProjectDetail.tsx", "default");
}),
"[project]/components/ProjectDetail.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProjectDetail$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/ProjectDetail.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProjectDetail$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/ProjectDetail.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProjectDetail$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/app/projects/[id]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProjectDetailPage,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProjectDetail$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ProjectDetail.tsx [app-rsc] (ecmascript)");
;
;
;
const dynamic = 'force-dynamic';
async function ProjectDetailPage({ params }) {
    // Handle params which might be a Promise in Next.js 15+
    const resolvedParams = await Promise.resolve(params);
    const projectId = parseInt(resolvedParams.id);
    let project, stats;
    try {
        project = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getProject"])(projectId);
        stats = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getProjectStats"])(projectId);
    } catch (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 py-8",
            children: "Failed to load project. Please ensure the backend is running."
        }, void 0, false, {
            fileName: "[project]/app/projects/[id]/page.tsx",
            lineNumber: 20,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ProjectDetail$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        project: project,
        stats: stats
    }, void 0, false, {
        fileName: "[project]/app/projects/[id]/page.tsx",
        lineNumber: 23,
        columnNumber: 10
    }, this);
}
}),
"[project]/app/projects/[id]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/projects/[id]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__af5f297a._.js.map