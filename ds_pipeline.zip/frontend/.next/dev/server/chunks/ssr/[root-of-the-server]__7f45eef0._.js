module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/lib/api.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API client for communicating with Django backend
 */ __turbopack_context__.s([
    "activateProject",
    ()=>activateProject,
    "createMilestone",
    ()=>createMilestone,
    "createPledge",
    ()=>createPledge,
    "createProject",
    ()=>createProject,
    "createRefund",
    ()=>createRefund,
    "createUpdate",
    ()=>createUpdate,
    "createVote",
    ()=>createVote,
    "deactivateProject",
    ()=>deactivateProject,
    "getCurrentUser",
    ()=>getCurrentUser,
    "getMilestones",
    ()=>getMilestones,
    "getMyProjects",
    ()=>getMyProjects,
    "getPledges",
    ()=>getPledges,
    "getProject",
    ()=>getProject,
    "getProjectStats",
    ()=>getProjectStats,
    "getProjects",
    ()=>getProjects,
    "getRefunds",
    ()=>getRefunds,
    "getUpdates",
    ()=>getUpdates,
    "getVotes",
    ()=>getVotes,
    "getWallets",
    ()=>getWallets,
    "login",
    ()=>login,
    "openVoting",
    ()=>openVoting,
    "register",
    ()=>register,
    "releaseFunds",
    ()=>releaseFunds
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
;
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api';
// Create axios instance
const apiClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});
// Add token to requests if available
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const login = async (username, password)=>{
    const response = await apiClient.post('/token/', {
        username,
        password
    });
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return response.data;
};
const register = async (data)=>{
    const response = await apiClient.post('/users/register/', data);
    return response.data;
};
const getCurrentUser = async ()=>{
    const response = await apiClient.get('/users/me/');
    return response.data;
};
const getProjects = async (params)=>{
    const response = await apiClient.get('/projects/', {
        params
    });
    return response.data.results || response.data;
};
const getProject = async (id)=>{
    const response = await apiClient.get(`/projects/${id}/`);
    return response.data;
};
const createProject = async (data)=>{
    const response = await apiClient.post('/projects/', data);
    return response.data;
};
const activateProject = async (id)=>{
    const response = await apiClient.post(`/projects/${id}/activate/`);
    return response.data;
};
const deactivateProject = async (id)=>{
    const response = await apiClient.post(`/projects/${id}/deactivate/`);
    return response.data;
};
const getProjectStats = async (id)=>{
    const response = await apiClient.get(`/projects/${id}/stats/`);
    return response.data;
};
const getMyProjects = async ()=>{
    const response = await apiClient.get('/projects/my_projects/');
    return response.data;
};
const getMilestones = async (projectId)=>{
    const params = projectId ? {
        project: projectId
    } : {};
    const response = await apiClient.get('/projects/milestones/', {
        params
    });
    return response.data.results || response.data;
};
const createMilestone = async (data)=>{
    const response = await apiClient.post('/projects/milestones/', data);
    return response.data;
};
const openVoting = async (milestoneId)=>{
    const response = await apiClient.post(`/projects/milestones/${milestoneId}/open_voting/`);
    return response.data;
};
const createPledge = async (projectId, data)=>{
    const response = await apiClient.post(`/projects/${projectId}/pledge/`, data);
    return response.data;
};
const getPledges = async (projectId)=>{
    const params = projectId ? {
        project: projectId
    } : {};
    const response = await apiClient.get('/finance/pledges/', {
        params
    });
    return response.data.results || response.data;
};
const createVote = async (data)=>{
    const response = await apiClient.post('/governance/votes/', data);
    return response.data;
};
const getVotes = async (milestoneId)=>{
    const params = milestoneId ? {
        milestone: milestoneId
    } : {};
    const response = await apiClient.get('/governance/votes/', {
        params
    });
    return response.data.results || response.data;
};
const releaseFunds = async (milestoneId)=>{
    const response = await apiClient.post(`/finance/releases/milestone/${milestoneId}/`);
    return response.data;
};
const createRefund = async (data)=>{
    const response = await apiClient.post('/finance/refunds/', data);
    return response.data;
};
const getRefunds = async ()=>{
    const response = await apiClient.get('/finance/refunds/');
    return response.data.results || response.data;
};
const getWallets = async ()=>{
    const response = await apiClient.get('/finance/wallets/');
    return response.data.results || response.data;
};
const getUpdates = async (projectId)=>{
    const params = projectId ? {
        project: projectId
    } : {};
    const response = await apiClient.get('/projects/updates/', {
        params
    });
    return response.data.results || response.data;
};
const createUpdate = async (data)=>{
    const response = await apiClient.post('/projects/updates/', data);
    return response.data;
};
}),
"[project]/hooks/useAuth.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-ssr] (ecmascript)");
;
;
;
function useAuth() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const loadUser = async ()=>{
        const token = localStorage.getItem('access_token');
        if (token) {
            try {
                const userData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getCurrentUser"])();
                setUser(userData);
            } catch (error) {
                localStorage.removeItem('access_token');
                localStorage.removeItem('refresh_token');
                setUser(null);
            } finally{
                setLoading(false);
            }
        } else {
            setUser(null);
            setLoading(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        loadUser();
        // Listen for storage changes (when token is set/removed from other tabs)
        const handleStorageChange = (e)=>{
            if (e.key === 'access_token') {
                loadUser();
            }
        };
        // Listen for custom login event (same window)
        const handleLogin = ()=>{
            loadUser();
        };
        window.addEventListener('storage', handleStorageChange);
        window.addEventListener('userLogin', handleLogin);
        return ()=>{
            window.removeEventListener('storage', handleStorageChange);
            window.removeEventListener('userLogin', handleLogin);
        };
    }, []);
    const logout = ()=>{
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        setUser(null);
        router.push('/');
    };
    return {
        user,
        loading,
        logout
    };
}
}),
"[project]/contexts/ThemeContext.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>ThemeProvider,
    "useTheme",
    ()=>useTheme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
const ThemeContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function ThemeProvider({ children }) {
    const [theme, setTheme] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('light');
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setMounted(true);
        // Get theme from localStorage or default to light
        const savedTheme = localStorage.getItem('theme');
        const initialTheme = savedTheme || 'light';
        setTheme(initialTheme);
        applyTheme(initialTheme);
    }, []);
    const applyTheme = (newTheme)=>{
        if ("TURBOPACK compile-time truthy", 1) return;
        //TURBOPACK unreachable
        ;
        const root = undefined;
    };
    const toggleTheme = ()=>{
        const newTheme = theme === 'light' ? 'dark' : 'light';
        setTheme(newTheme);
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        applyTheme(newTheme);
    };
    // Always provide the context, even before mount (prevents errors)
    // Default to light theme during SSR
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ThemeContext.Provider, {
        value: {
            theme: mounted ? theme : 'light',
            toggleTheme
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/ThemeContext.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
}
function useTheme() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(ThemeContext);
    if (context === undefined) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
}
}),
"[project]/components/ThemeToggle.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/ThemeContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.esm.js [app-ssr] (ecmascript)");
'use client';
;
;
;
const ThemeToggle = ()=>{
    const { theme, toggleTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$ThemeContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useTheme"])();
    const isDark = theme === 'dark';
    const handleChange = ()=>{
        toggleTheme();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StyledWrapper, {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "switch",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    id: "checkbox",
                    type: "checkbox",
                    checked: isDark,
                    onChange: handleChange,
                    "aria-label": "Toggle dark mode"
                }, void 0, false, {
                    fileName: "[project]/components/ThemeToggle.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "slider",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "star star_1"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemeToggle.tsx",
                            lineNumber: 25,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "star star_2"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemeToggle.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "star star_3"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemeToggle.tsx",
                            lineNumber: 27,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            viewBox: "0 0 16 16",
                            className: "cloud_1 cloud",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                transform: "matrix(.77976 0 0 .78395-299.99-418.63)",
                                fill: "#fff",
                                d: "m391.84 540.91c-.421-.329-.949-.524-1.523-.524-1.351 0-2.451 1.084-2.485 2.435-1.395.526-2.388 1.88-2.388 3.466 0 1.874 1.385 3.423 3.182 3.667v.034h12.73v-.006c1.775-.104 3.182-1.584 3.182-3.395 0-1.747-1.309-3.186-2.994-3.379.007-.106.011-.214.011-.322 0-2.707-2.271-4.901-5.072-4.901-2.073 0-3.856 1.202-4.643 2.925"
                            }, void 0, false, {
                                fileName: "[project]/components/ThemeToggle.tsx",
                                lineNumber: 29,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/components/ThemeToggle.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ThemeToggle.tsx",
                    lineNumber: 24,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/ThemeToggle.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/ThemeToggle.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const StyledWrapper = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].div`
  /* Theme Switch */
  /* The switch - the box around the slider */
  .switch {
    font-size: 17px;
    position: relative;
    display: inline-block;
    width: 4em;
    height: 2.2em;
    border-radius: 30px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  /* Hide default HTML checkbox */
  .switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  /* The slider */
  .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #2a2a2a;
    transition: 0.4s;
    border-radius: 30px;
    overflow: hidden;
  }

  .slider:before {
    position: absolute;
    content: "";
    height: 1.2em;
    width: 1.2em;
    border-radius: 20px;
    left: 0.5em;
    bottom: 0.5em;
    transition: 0.4s;
    transition-timing-function: cubic-bezier(0.81, -0.04, 0.38, 1.5);
    box-shadow: inset 8px -4px 0px 0px #fff;
  }

  .switch input:checked + .slider {
    background-color: #00a6ff;
  }

  .switch input:checked + .slider:before {
    transform: translateX(1.8em);
    box-shadow: inset 15px -4px 0px 15px #ffcf48;
  }

  .star {
    background-color: #fff;
    border-radius: 50%;
    position: absolute;
    width: 5px;
    transition: all 0.4s;
    height: 5px;
  }

  .star_1 {
    left: 2.5em;
    top: 0.5em;
  }

  .star_2 {
    left: 2.2em;
    top: 1.2em;
  }

  .star_3 {
    left: 3em;
    top: 0.9em;
  }

  .switch input:checked ~ .slider .star {
    opacity: 0;
  }

  .cloud {
    width: 3.5em;
    position: absolute;
    bottom: -1.4em;
    left: -1.1em;
    opacity: 0;
    transition: all 0.4s;
  }

  .switch input:checked ~ .slider .cloud {
    opacity: 1;
  }`;
const __TURBOPACK__default__export__ = ThemeToggle;
 // import React from 'react';
 // import styled from 'styled-components';
 // const Switch = () => {
 //   return (
 //     <StyledWrapper>
 //       <label className="bb8-toggle">
 //         <input className="bb8-toggle__checkbox" type="checkbox" />
 //         <div className="bb8-toggle__container">
 //           <div className="bb8-toggle__scenery">
 //             <div className="bb8-toggle__star" />
 //             <div className="bb8-toggle__star" />
 //             <div className="bb8-toggle__star" />
 //             <div className="bb8-toggle__star" />
 //             <div className="bb8-toggle__star" />
 //             <div className="bb8-toggle__star" />
 //             <div className="bb8-toggle__star" />
 //             <div className="tatto-1" />
 //             <div className="tatto-2" />
 //             <div className="gomrassen" />
 //             <div className="hermes" />
 //             <div className="chenini" />
 //             <div className="bb8-toggle__cloud" />
 //             <div className="bb8-toggle__cloud" />
 //             <div className="bb8-toggle__cloud" />
 //           </div>
 //           <div className="bb8">
 //             <div className="bb8__head-container">
 //               <div className="bb8__antenna" />
 //               <div className="bb8__antenna" />
 //               <div className="bb8__head" />
 //             </div>
 //             <div className="bb8__body" />
 //           </div>
 //           <div className="artificial__hidden">
 //             <div className="bb8__shadow" />
 //           </div>
 //         </div>
 //       </label>
 //     </StyledWrapper>
 //   );
 // }
 // const StyledWrapper = styled.div`
 //   /* REMASTERED */
 //   /* RTX-ON */
 //   /* completely redone toggle and droid */
 //   .bb8-toggle {
 //     --toggle-size: 16px;
 //     /* finally I removed the scale now everything depends on the font-size */
 //     /* --margin-top-for-head: 1.75em; */
 //     /* it's just in case 👆 */
 //     --toggle-width: 10.625em;
 //     --toggle-height: 5.625em;
 //     --toggle-offset: calc((var(--toggle-height) - var(--bb8-diameter)) / 2);
 //     --toggle-bg: linear-gradient(#2c4770, #070e2b 35%, #628cac 50% 70%, #a6c5d4)
 //       no-repeat;
 //     --bb8-diameter: 4.375em;
 //     --radius: 99em;
 //     --transition: 0.4s;
 //     --accent: #de7d2f;
 //     --bb8-bg: #fff;
 //   }
 //   .bb8-toggle,
 //   .bb8-toggle *,
 //   .bb8-toggle *::before,
 //   .bb8-toggle *::after {
 //     -webkit-box-sizing: border-box;
 //     box-sizing: border-box;
 //   }
 //   .bb8-toggle {
 //     cursor: pointer;
 //     margin-top: var(--margin-top-for-head);
 //     font-size: var(--toggle-size);
 //   }
 //   .bb8-toggle__checkbox {
 //     -webkit-appearance: none;
 //     -moz-appearance: none;
 //     appearance: none;
 //     display: none;
 //   }
 //   .bb8-toggle__container {
 //     width: var(--toggle-width);
 //     height: var(--toggle-height);
 //     background: var(--toggle-bg);
 //     background-size: 100% 11.25em;
 //     background-position-y: -5.625em;
 //     border-radius: var(--radius);
 //     position: relative;
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //   }
 //   .bb8 {
 //     display: -webkit-box;
 //     display: -ms-flexbox;
 //     display: flex;
 //     -webkit-box-orient: vertical;
 //     -webkit-box-direction: normal;
 //     -ms-flex-direction: column;
 //     flex-direction: column;
 //     -webkit-box-align: center;
 //     -ms-flex-align: center;
 //     align-items: center;
 //     position: absolute;
 //     top: calc(var(--toggle-offset) - 1.688em + 0.188em);
 //     left: var(--toggle-offset);
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //     z-index: 2;
 //   }
 //   .bb8__head-container {
 //     position: relative;
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //     z-index: 2;
 //     -webkit-transform-origin: 1.25em 3.75em;
 //     -ms-transform-origin: 1.25em 3.75em;
 //     transform-origin: 1.25em 3.75em;
 //   }
 //   .bb8__head {
 //     overflow: hidden;
 //     margin-bottom: -0.188em;
 //     width: 2.5em;
 //     height: 1.688em;
 //     background: -o-linear-gradient(
 //         transparent 0.063em,
 //         dimgray 0.063em 0.313em,
 //         transparent 0.313em 0.375em,
 //         var(--accent) 0.375em 0.5em,
 //         transparent 0.5em 1.313em,
 //         silver 1.313em 1.438em,
 //         transparent 1.438em
 //       ),
 //       -o-linear-gradient(45deg, transparent 0.188em, var(--bb8-bg) 0.188em 1.25em, transparent
 //             1.25em),
 //       -o-linear-gradient(135deg, transparent 0.188em, var(--bb8-bg) 0.188em 1.25em, transparent
 //             1.25em),
 //       -o-linear-gradient(var(--bb8-bg) 1.25em, transparent 1.25em);
 //     background: -o-linear-gradient(
 //         transparent 0.063em,
 //         dimgray 0.063em 0.313em,
 //         transparent 0.313em 0.375em,
 //         var(--accent) 0.375em 0.5em,
 //         transparent 0.5em 1.313em,
 //         silver 1.313em 1.438em,
 //         transparent 1.438em
 //       ),
 //       -o-linear-gradient(45deg, transparent 0.188em, var(--bb8-bg) 0.188em 1.25em, transparent
 //             1.25em),
 //       -o-linear-gradient(135deg, transparent 0.188em, var(--bb8-bg) 0.188em 1.25em, transparent
 //             1.25em),
 //       -o-linear-gradient(var(--bb8-bg) 1.25em, transparent 1.25em);
 //     background: -o-linear-gradient(
 //         transparent 0.063em,
 //         dimgray 0.063em 0.313em,
 //         transparent 0.313em 0.375em,
 //         var(--accent) 0.375em 0.5em,
 //         transparent 0.5em 1.313em,
 //         silver 1.313em 1.438em,
 //         transparent 1.438em
 //       ),
 //       -o-linear-gradient(45deg, transparent 0.188em, var(--bb8-bg) 0.188em 1.25em, transparent
 //             1.25em),
 //       -o-linear-gradient(135deg, transparent 0.188em, var(--bb8-bg) 0.188em 1.25em, transparent
 //             1.25em),
 //       -o-linear-gradient(var(--bb8-bg) 1.25em, transparent 1.25em);
 //     background: -o-linear-gradient(
 //         transparent 0.063em,
 //         dimgray 0.063em 0.313em,
 //         transparent 0.313em 0.375em,
 //         var(--accent) 0.375em 0.5em,
 //         transparent 0.5em 1.313em,
 //         silver 1.313em 1.438em,
 //         transparent 1.438em
 //       ),
 //       -o-linear-gradient(45deg, transparent 0.188em, var(--bb8-bg) 0.188em 1.25em, transparent
 //             1.25em),
 //       -o-linear-gradient(135deg, transparent 0.188em, var(--bb8-bg) 0.188em 1.25em, transparent
 //             1.25em),
 //       -o-linear-gradient(var(--bb8-bg) 1.25em, transparent 1.25em);
 //     background: linear-gradient(
 //         transparent 0.063em,
 //         dimgray 0.063em 0.313em,
 //         transparent 0.313em 0.375em,
 //         var(--accent) 0.375em 0.5em,
 //         transparent 0.5em 1.313em,
 //         silver 1.313em 1.438em,
 //         transparent 1.438em
 //       ),
 //       linear-gradient(
 //         45deg,
 //         transparent 0.188em,
 //         var(--bb8-bg) 0.188em 1.25em,
 //         transparent 1.25em
 //       ),
 //       linear-gradient(
 //         -45deg,
 //         transparent 0.188em,
 //         var(--bb8-bg) 0.188em 1.25em,
 //         transparent 1.25em
 //       ),
 //       linear-gradient(var(--bb8-bg) 1.25em, transparent 1.25em);
 //     border-radius: var(--radius) var(--radius) 0 0;
 //     position: relative;
 //     z-index: 1;
 //     -webkit-filter: drop-shadow(0 0.063em 0.125em gray);
 //     filter: drop-shadow(0 0.063em 0.125em gray);
 //   }
 //   .bb8__head::before {
 //     content: "";
 //     position: absolute;
 //     width: 0.563em;
 //     height: 0.563em;
 //     background: -o-radial-gradient(
 //         0.25em 0.375em,
 //         0.125em circle,
 //         red,
 //         transparent
 //       ),
 //       -o-radial-gradient(0.375em 0.188em, 0.063em circle, var(--bb8-bg) 50%, transparent
 //             100%),
 //       -o-linear-gradient(45deg, #000 0.188em, dimgray 0.313em 0.375em, #000 0.5em);
 //     background: -o-radial-gradient(
 //         0.25em 0.375em,
 //         0.125em circle,
 //         red,
 //         transparent
 //       ),
 //       -o-radial-gradient(0.375em 0.188em, 0.063em circle, var(--bb8-bg) 50%, transparent
 //             100%),
 //       -o-linear-gradient(45deg, #000 0.188em, dimgray 0.313em 0.375em, #000 0.5em);
 //     background: -o-radial-gradient(
 //         0.25em 0.375em,
 //         0.125em circle,
 //         red,
 //         transparent
 //       ),
 //       -o-radial-gradient(0.375em 0.188em, 0.063em circle, var(--bb8-bg) 50%, transparent
 //             100%),
 //       -o-linear-gradient(45deg, #000 0.188em, dimgray 0.313em 0.375em, #000 0.5em);
 //     background: -o-radial-gradient(
 //         0.25em 0.375em,
 //         0.125em circle,
 //         red,
 //         transparent
 //       ),
 //       -o-radial-gradient(0.375em 0.188em, 0.063em circle, var(--bb8-bg) 50%, transparent
 //             100%),
 //       -o-linear-gradient(45deg, #000 0.188em, dimgray 0.313em 0.375em, #000 0.5em);
 //     background: radial-gradient(
 //         0.125em circle at 0.25em 0.375em,
 //         red,
 //         transparent
 //       ),
 //       radial-gradient(
 //         0.063em circle at 0.375em 0.188em,
 //         var(--bb8-bg) 50%,
 //         transparent 100%
 //       ),
 //       linear-gradient(45deg, #000 0.188em, dimgray 0.313em 0.375em, #000 0.5em);
 //     border-radius: var(--radius);
 //     top: 0.413em;
 //     left: 50%;
 //     -webkit-transform: translate(-50%);
 //     -ms-transform: translate(-50%);
 //     transform: translate(-50%);
 //     -webkit-box-shadow: 0 0 0 0.089em lightgray, 0.563em 0.281em 0 -0.148em,
 //       0.563em 0.281em 0 -0.1em var(--bb8-bg), 0.563em 0.281em 0 -0.063em;
 //     box-shadow: 0 0 0 0.089em lightgray, 0.563em 0.281em 0 -0.148em,
 //       0.563em 0.281em 0 -0.1em var(--bb8-bg), 0.563em 0.281em 0 -0.063em;
 //     z-index: 1;
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //   }
 //   .bb8__head::after {
 //     content: "";
 //     position: absolute;
 //     bottom: 0.375em;
 //     left: 0;
 //     width: 100%;
 //     height: 0.188em;
 //     background: -o-linear-gradient(
 //       left,
 //       var(--accent) 0.125em,
 //       transparent 0.125em 0.188em,
 //       var(--accent) 0.188em 0.313em,
 //       transparent 0.313em 0.375em,
 //       var(--accent) 0.375em 0.938em,
 //       transparent 0.938em 1em,
 //       var(--accent) 1em 1.125em,
 //       transparent 1.125em 1.875em,
 //       var(--accent) 1.875em 2em,
 //       transparent 2em 2.063em,
 //       var(--accent) 2.063em 2.25em,
 //       transparent 2.25em 2.313em,
 //       var(--accent) 2.313em 2.375em,
 //       transparent 2.375em 2.438em,
 //       var(--accent) 2.438em
 //     );
 //     background: -webkit-gradient(
 //       linear,
 //       left top,
 //       right top,
 //       color-stop(0.125em, var(--accent)),
 //       color-stop(0.125em, transparent),
 //       color-stop(0.188em, var(--accent)),
 //       color-stop(0.313em, transparent),
 //       color-stop(0.375em, var(--accent)),
 //       color-stop(0.938em, transparent),
 //       color-stop(1em, var(--accent)),
 //       color-stop(1.125em, transparent),
 //       color-stop(1.875em, var(--accent)),
 //       color-stop(2em, transparent),
 //       color-stop(2.063em, var(--accent)),
 //       color-stop(2.25em, transparent),
 //       color-stop(2.313em, var(--accent)),
 //       color-stop(2.375em, transparent),
 //       color-stop(2.438em, var(--accent))
 //     );
 //     background: linear-gradient(
 //       to right,
 //       var(--accent) 0.125em,
 //       transparent 0.125em 0.188em,
 //       var(--accent) 0.188em 0.313em,
 //       transparent 0.313em 0.375em,
 //       var(--accent) 0.375em 0.938em,
 //       transparent 0.938em 1em,
 //       var(--accent) 1em 1.125em,
 //       transparent 1.125em 1.875em,
 //       var(--accent) 1.875em 2em,
 //       transparent 2em 2.063em,
 //       var(--accent) 2.063em 2.25em,
 //       transparent 2.25em 2.313em,
 //       var(--accent) 2.313em 2.375em,
 //       transparent 2.375em 2.438em,
 //       var(--accent) 2.438em
 //     );
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //   }
 //   .bb8__antenna {
 //     position: absolute;
 //     -webkit-transform: translateY(-90%);
 //     -ms-transform: translateY(-90%);
 //     transform: translateY(-90%);
 //     width: 0.059em;
 //     border-radius: var(--radius) var(--radius) 0 0;
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //   }
 //   .bb8__antenna:nth-child(1) {
 //     height: 0.938em;
 //     right: 0.938em;
 //     background: -o-linear-gradient(#000 0.188em, silver 0.188em);
 //     background: -webkit-gradient(
 //       linear,
 //       left top,
 //       left bottom,
 //       color-stop(0.188em, #000),
 //       color-stop(0.188em, silver)
 //     );
 //     background: linear-gradient(#000 0.188em, silver 0.188em);
 //   }
 //   .bb8__antenna:nth-child(2) {
 //     height: 0.375em;
 //     left: 50%;
 //     -webkit-transform: translate(-50%, -90%);
 //     -ms-transform: translate(-50%, -90%);
 //     transform: translate(-50%, -90%);
 //     background: silver;
 //   }
 //   .bb8__body {
 //     width: 4.375em;
 //     height: 4.375em;
 //     background: var(--bb8-bg);
 //     border-radius: var(--radius);
 //     position: relative;
 //     overflow: hidden;
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //     z-index: 1;
 //     -webkit-transform: rotate(45deg);
 //     -ms-transform: rotate(45deg);
 //     transform: rotate(45deg);
 //     background: -webkit-gradient(
 //         linear,
 //         right top,
 //         left top,
 //         color-stop(4%, var(--bb8-bg)),
 //         color-stop(4%, var(--accent)),
 //         color-stop(10%, transparent),
 //         color-stop(90%, var(--accent)),
 //         color-stop(96%, var(--bb8-bg))
 //       ),
 //       -webkit-gradient(linear, left top, left bottom, color-stop(4%, var(--bb8-bg)), color-stop(4%, var(--accent)), color-stop(10%, transparent), color-stop(90%, var(--accent)), color-stop(96%, var(--bb8-bg))),
 //       -webkit-gradient(linear, left top, right top, color-stop(2.156em, transparent), color-stop(2.156em, silver), color-stop(2.188em, transparent)),
 //       -webkit-gradient(linear, left top, left bottom, color-stop(2.156em, transparent), color-stop(2.156em, silver), color-stop(2.188em, transparent));
 //     background: -o-linear-gradient(
 //         right,
 //         var(--bb8-bg) 4%,
 //         var(--accent) 4% 10%,
 //         transparent 10% 90%,
 //         var(--accent) 90% 96%,
 //         var(--bb8-bg) 96%
 //       ),
 //       -o-linear-gradient(var(--bb8-bg) 4%, var(--accent) 4% 10%, transparent 10%
 //             90%, var(--accent) 90% 96%, var(--bb8-bg) 96%),
 //       -o-linear-gradient(left, transparent 2.156em, silver 2.156em 2.219em, transparent
 //             2.188em),
 //       -o-linear-gradient(transparent 2.156em, silver 2.156em 2.219em, transparent
 //             2.188em);
 //     background: linear-gradient(
 //         -90deg,
 //         var(--bb8-bg) 4%,
 //         var(--accent) 4% 10%,
 //         transparent 10% 90%,
 //         var(--accent) 90% 96%,
 //         var(--bb8-bg) 96%
 //       ),
 //       linear-gradient(
 //         var(--bb8-bg) 4%,
 //         var(--accent) 4% 10%,
 //         transparent 10% 90%,
 //         var(--accent) 90% 96%,
 //         var(--bb8-bg) 96%
 //       ),
 //       linear-gradient(
 //         to right,
 //         transparent 2.156em,
 //         silver 2.156em 2.219em,
 //         transparent 2.188em
 //       ),
 //       linear-gradient(
 //         transparent 2.156em,
 //         silver 2.156em 2.219em,
 //         transparent 2.188em
 //       );
 //     background-color: var(--bb8-bg);
 //   }
 //   .bb8__body::after {
 //     content: "";
 //     bottom: 1.5em;
 //     left: 0.563em;
 //     position: absolute;
 //     width: 0.188em;
 //     height: 0.188em;
 //     background: rgb(236, 236, 236);
 //     color: rgb(236, 236, 236);
 //     border-radius: 50%;
 //     -webkit-box-shadow: 0.875em 0.938em, 0 -1.25em, 0.875em -2.125em,
 //       2.125em -2.125em, 3.063em -1.25em, 3.063em 0, 2.125em 0.938em;
 //     box-shadow: 0.875em 0.938em, 0 -1.25em, 0.875em -2.125em, 2.125em -2.125em,
 //       3.063em -1.25em, 3.063em 0, 2.125em 0.938em;
 //   }
 //   .bb8__body::before {
 //     content: "";
 //     width: 2.625em;
 //     height: 2.625em;
 //     position: absolute;
 //     border-radius: 50%;
 //     z-index: 0.1;
 //     overflow: hidden;
 //     top: 50%;
 //     left: 50%;
 //     -webkit-transform: translate(-50%, -50%);
 //     -ms-transform: translate(-50%, -50%);
 //     transform: translate(-50%, -50%);
 //     border: 0.313em solid var(--accent);
 //     background: -o-radial-gradient(
 //         center,
 //         1em circle,
 //         rgb(236, 236, 236) 50%,
 //         transparent 51%
 //       ),
 //       -o-radial-gradient(center, 1.25em circle, var(--bb8-bg) 50%, transparent 51%),
 //       -o-linear-gradient(right, transparent 42%, var(--accent) 42% 58%, transparent
 //             58%),
 //       -o-linear-gradient(var(--bb8-bg) 42%, var(--accent) 42% 58%, var(--bb8-bg)
 //             58%);
 //     background: -o-radial-gradient(
 //         center,
 //         1em circle,
 //         rgb(236, 236, 236) 50%,
 //         transparent 51%
 //       ),
 //       -o-radial-gradient(center, 1.25em circle, var(--bb8-bg) 50%, transparent 51%),
 //       -o-linear-gradient(right, transparent 42%, var(--accent) 42% 58%, transparent
 //             58%),
 //       -o-linear-gradient(var(--bb8-bg) 42%, var(--accent) 42% 58%, var(--bb8-bg)
 //             58%);
 //     background: radial-gradient(
 //         1em circle at center,
 //         rgb(236, 236, 236) 50%,
 //         transparent 51%
 //       ),
 //       radial-gradient(1.25em circle at center, var(--bb8-bg) 50%, transparent 51%),
 //       -webkit-gradient(linear, right top, left top, color-stop(42%, transparent), color-stop(42%, var(--accent)), color-stop(58%, transparent)),
 //       -webkit-gradient(linear, left top, left bottom, color-stop(42%, var(--bb8-bg)), color-stop(42%, var(--accent)), color-stop(58%, var(--bb8-bg)));
 //     background: radial-gradient(
 //         1em circle at center,
 //         rgb(236, 236, 236) 50%,
 //         transparent 51%
 //       ),
 //       radial-gradient(1.25em circle at center, var(--bb8-bg) 50%, transparent 51%),
 //       linear-gradient(
 //         -90deg,
 //         transparent 42%,
 //         var(--accent) 42% 58%,
 //         transparent 58%
 //       ),
 //       linear-gradient(var(--bb8-bg) 42%, var(--accent) 42% 58%, var(--bb8-bg) 58%);
 //   }
 //   .artificial__hidden {
 //     position: absolute;
 //     border-radius: inherit;
 //     inset: 0;
 //     pointer-events: none;
 //     overflow: hidden;
 //   }
 //   .bb8__shadow {
 //     content: "";
 //     width: var(--bb8-diameter);
 //     height: 20%;
 //     border-radius: 50%;
 //     background: #3a271c;
 //     -webkit-box-shadow: 0.313em 0 3.125em #3a271c;
 //     box-shadow: 0.313em 0 3.125em #3a271c;
 //     opacity: 0.25;
 //     position: absolute;
 //     bottom: 0;
 //     left: calc(var(--toggle-offset) - 0.938em);
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //     -webkit-transform: skew(-70deg);
 //     -ms-transform: skew(-70deg);
 //     transform: skew(-70deg);
 //     z-index: 1;
 //   }
 //   .bb8-toggle__scenery {
 //     width: 100%;
 //     height: 100%;
 //     pointer-events: none;
 //     overflow: hidden;
 //     position: relative;
 //     border-radius: inherit;
 //   }
 //   .bb8-toggle__scenery::before {
 //     content: "";
 //     position: absolute;
 //     width: 100%;
 //     height: 30%;
 //     bottom: 0;
 //     background: #b18d71;
 //     z-index: 1;
 //   }
 //   .bb8-toggle__cloud {
 //     z-index: 1;
 //     position: absolute;
 //     border-radius: 50%;
 //   }
 //   .bb8-toggle__cloud:nth-last-child(1) {
 //     width: 0.875em;
 //     height: 0.625em;
 //     -webkit-filter: blur(0.125em) drop-shadow(0.313em 0.313em #ffffffae)
 //       drop-shadow(-0.625em 0 #fff) drop-shadow(-0.938em -0.125em #fff);
 //     filter: blur(0.125em) drop-shadow(0.313em 0.313em #ffffffae)
 //       drop-shadow(-0.625em 0 #fff) drop-shadow(-0.938em -0.125em #fff);
 //     right: 1.875em;
 //     top: 2.813em;
 //     background: -o-linear-gradient(bottom left, #ffffffae, #ffffffae);
 //     background: -webkit-gradient(
 //       linear,
 //       left bottom,
 //       right top,
 //       from(#ffffffae),
 //       to(#ffffffae)
 //     );
 //     background: linear-gradient(to top right, #ffffffae, #ffffffae);
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //   }
 //   .bb8-toggle__cloud:nth-last-child(2) {
 //     top: 0.625em;
 //     right: 4.375em;
 //     width: 0.875em;
 //     height: 0.375em;
 //     background: #dfdedeae;
 //     -webkit-filter: blur(0.125em) drop-shadow(-0.313em -0.188em #e0dfdfae)
 //       drop-shadow(-0.625em -0.188em #bbbbbbae) drop-shadow(-1em 0.063em #cfcfcfae);
 //     filter: blur(0.125em) drop-shadow(-0.313em -0.188em #e0dfdfae)
 //       drop-shadow(-0.625em -0.188em #bbbbbbae) drop-shadow(-1em 0.063em #cfcfcfae);
 //     -webkit-transition: 0.6s;
 //     -o-transition: 0.6s;
 //     transition: 0.6s;
 //   }
 //   .bb8-toggle__cloud:nth-last-child(3) {
 //     top: 1.25em;
 //     right: 0.938em;
 //     width: 0.875em;
 //     height: 0.375em;
 //     background: #ffffffae;
 //     -webkit-filter: blur(0.125em) drop-shadow(0.438em 0.188em #ffffffae)
 //       drop-shadow(-0.625em 0.313em #ffffffae);
 //     filter: blur(0.125em) drop-shadow(0.438em 0.188em #ffffffae)
 //       drop-shadow(-0.625em 0.313em #ffffffae);
 //     -webkit-transition: 0.8s;
 //     -o-transition: 0.8s;
 //     transition: 0.8s;
 //   }
 //   .gomrassen,
 //   .hermes,
 //   .chenini {
 //     position: absolute;
 //     border-radius: var(--radius);
 //     background: -o-linear-gradient(#fff, #6e8ea2);
 //     background: -webkit-gradient(
 //       linear,
 //       left top,
 //       left bottom,
 //       from(#fff),
 //       to(#6e8ea2)
 //     );
 //     background: linear-gradient(#fff, #6e8ea2);
 //     top: 100%;
 //   }
 //   .gomrassen {
 //     left: 0.938em;
 //     width: 1.875em;
 //     height: 1.875em;
 //     -webkit-box-shadow: 0 0 0.188em #ffffff52, 0 0 0.188em #6e8ea24b;
 //     box-shadow: 0 0 0.188em #ffffff52, 0 0 0.188em #6e8ea24b;
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //   }
 //   .gomrassen::before,
 //   .gomrassen::after {
 //     content: "";
 //     position: absolute;
 //     border-radius: inherit;
 //     -webkit-box-shadow: inset 0 0 0.063em rgb(140, 162, 169);
 //     box-shadow: inset 0 0 0.063em rgb(140, 162, 169);
 //     background: rgb(184, 196, 200);
 //   }
 //   .gomrassen::before {
 //     left: 0.313em;
 //     top: 0.313em;
 //     width: 0.438em;
 //     height: 0.438em;
 //   }
 //   .gomrassen::after {
 //     width: 0.25em;
 //     height: 0.25em;
 //     left: 1.25em;
 //     top: 0.75em;
 //   }
 //   .hermes {
 //     left: 3.438em;
 //     width: 0.625em;
 //     height: 0.625em;
 //     -webkit-box-shadow: 0 0 0.125em #ffffff52, 0 0 0.125em #6e8ea24b;
 //     box-shadow: 0 0 0.125em #ffffff52, 0 0 0.125em #6e8ea24b;
 //     -webkit-transition: 0.6s;
 //     -o-transition: 0.6s;
 //     transition: 0.6s;
 //   }
 //   .chenini {
 //     left: 4.375em;
 //     width: 0.5em;
 //     height: 0.5em;
 //     -webkit-box-shadow: 0 0 0.125em #ffffff52, 0 0 0.125em #6e8ea24b;
 //     box-shadow: 0 0 0.125em #ffffff52, 0 0 0.125em #6e8ea24b;
 //     -webkit-transition: 0.8s;
 //     -o-transition: 0.8s;
 //     transition: 0.8s;
 //   }
 //   .tatto-1,
 //   .tatto-2 {
 //     position: absolute;
 //     width: 1.25em;
 //     height: 1.25em;
 //     border-radius: var(--radius);
 //   }
 //   .tatto-1 {
 //     background: #fefefe;
 //     right: 3.125em;
 //     top: 0.625em;
 //     -webkit-box-shadow: 0 0 0.438em #fdf4e1;
 //     box-shadow: 0 0 0.438em #fdf4e1;
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //   }
 //   .tatto-2 {
 //     background: -o-linear-gradient(#e6ac5c, #d75449);
 //     background: -webkit-gradient(
 //       linear,
 //       left top,
 //       left bottom,
 //       from(#e6ac5c),
 //       to(#d75449)
 //     );
 //     background: linear-gradient(#e6ac5c, #d75449);
 //     right: 1.25em;
 //     top: 2.188em;
 //     -webkit-box-shadow: 0 0 0.438em #e6ad5c3d, 0 0 0.438em #d755494f;
 //     box-shadow: 0 0 0.438em #e6ad5c3d, 0 0 0.438em #d755494f;
 //     -webkit-transition: 0.7s;
 //     -o-transition: 0.7s;
 //     transition: 0.7s;
 //   }
 //   .bb8-toggle__star {
 //     position: absolute;
 //     width: 0.063em;
 //     height: 0.063em;
 //     background: #fff;
 //     border-radius: var(--radius);
 //     -webkit-filter: drop-shadow(0 0 0.063em #fff);
 //     filter: drop-shadow(0 0 0.063em #fff);
 //     color: #fff;
 //     top: 100%;
 //   }
 //   .bb8-toggle__star:nth-child(1) {
 //     left: 3.75em;
 //     -webkit-box-shadow: 1.25em 0.938em, -1.25em 2.5em, 0 1.25em, 1.875em 0.625em,
 //       -3.125em 1.875em, 1.25em 2.813em;
 //     box-shadow: 1.25em 0.938em, -1.25em 2.5em, 0 1.25em, 1.875em 0.625em,
 //       -3.125em 1.875em, 1.25em 2.813em;
 //     -webkit-transition: 0.2s;
 //     -o-transition: 0.2s;
 //     transition: 0.2s;
 //   }
 //   .bb8-toggle__star:nth-child(2) {
 //     left: 4.688em;
 //     -webkit-box-shadow: 0.625em 0, 0 0.625em, -0.625em -0.625em, 0.625em 0.938em,
 //       -3.125em 1.25em, 1.25em -1.563em;
 //     box-shadow: 0.625em 0, 0 0.625em, -0.625em -0.625em, 0.625em 0.938em,
 //       -3.125em 1.25em, 1.25em -1.563em;
 //     -webkit-transition: 0.3s;
 //     -o-transition: 0.3s;
 //     transition: 0.3s;
 //   }
 //   .bb8-toggle__star:nth-child(3) {
 //     left: 5.313em;
 //     -webkit-box-shadow: -0.625em -0.625em, -2.188em 1.25em, -2.188em 0,
 //       -3.75em -0.625em, -3.125em -0.625em, -2.5em -0.313em, 0.75em -0.625em;
 //     box-shadow: -0.625em -0.625em, -2.188em 1.25em, -2.188em 0, -3.75em -0.625em,
 //       -3.125em -0.625em, -2.5em -0.313em, 0.75em -0.625em;
 //     -webkit-transition: var(--transition);
 //     -o-transition: var(--transition);
 //     transition: var(--transition);
 //   }
 //   .bb8-toggle__star:nth-child(4) {
 //     left: 1.875em;
 //     width: 0.125em;
 //     height: 0.125em;
 //     -webkit-transition: 0.5s;
 //     -o-transition: 0.5s;
 //     transition: 0.5s;
 //   }
 //   .bb8-toggle__star:nth-child(5) {
 //     left: 5em;
 //     width: 0.125em;
 //     height: 0.125em;
 //     -webkit-transition: 0.6s;
 //     -o-transition: 0.6s;
 //     transition: 0.6s;
 //   }
 //   .bb8-toggle__star:nth-child(6) {
 //     left: 2.5em;
 //     width: 0.125em;
 //     height: 0.125em;
 //     -webkit-transition: 0.7s;
 //     -o-transition: 0.7s;
 //     transition: 0.7s;
 //   }
 //   .bb8-toggle__star:nth-child(7) {
 //     left: 3.438em;
 //     width: 0.125em;
 //     height: 0.125em;
 //     -webkit-transition: 0.8s;
 //     -o-transition: 0.8s;
 //     transition: 0.8s;
 //   }
 //   /* actions */
 //   .bb8-toggle__checkbox:checked
 //     + .bb8-toggle__container
 //     .bb8-toggle__star:nth-child(1) {
 //     top: 0.625em;
 //   }
 //   .bb8-toggle__checkbox:checked
 //     + .bb8-toggle__container
 //     .bb8-toggle__star:nth-child(2) {
 //     top: 1.875em;
 //   }
 //   .bb8-toggle__checkbox:checked
 //     + .bb8-toggle__container
 //     .bb8-toggle__star:nth-child(3) {
 //     top: 1.25em;
 //   }
 //   .bb8-toggle__checkbox:checked
 //     + .bb8-toggle__container
 //     .bb8-toggle__star:nth-child(4) {
 //     top: 3.438em;
 //   }
 //   .bb8-toggle__checkbox:checked
 //     + .bb8-toggle__container
 //     .bb8-toggle__star:nth-child(5) {
 //     top: 3.438em;
 //   }
 //   .bb8-toggle__checkbox:checked
 //     + .bb8-toggle__container
 //     .bb8-toggle__star:nth-child(6) {
 //     top: 0.313em;
 //   }
 //   .bb8-toggle__checkbox:checked
 //     + .bb8-toggle__container
 //     .bb8-toggle__star:nth-child(7) {
 //     top: 1.875em;
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .bb8-toggle__cloud {
 //     right: -100%;
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .gomrassen {
 //     top: 0.938em;
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .hermes {
 //     top: 2.5em;
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .chenini {
 //     top: 2.75em;
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container {
 //     background-position-y: 0;
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .tatto-1 {
 //     top: 100%;
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .tatto-2 {
 //     top: 100%;
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .bb8 {
 //     left: calc(100% - var(--bb8-diameter) - var(--toggle-offset));
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .bb8__shadow {
 //     left: calc(100% - var(--bb8-diameter) - var(--toggle-offset) + 0.938em);
 //     -webkit-transform: skew(70deg);
 //     -ms-transform: skew(70deg);
 //     transform: skew(70deg);
 //   }
 //   .bb8-toggle__checkbox:checked + .bb8-toggle__container .bb8__body {
 //     -webkit-transform: rotate(180deg);
 //     -ms-transform: rotate(180deg);
 //     transform: rotate(225deg);
 //   }
 //   .bb8-toggle__checkbox:hover + .bb8-toggle__container .bb8__head::before {
 //     left: 100%;
 //   }
 //   .bb8-toggle__checkbox:not(:checked):hover
 //     + .bb8-toggle__container
 //     .bb8__antenna:nth-child(1) {
 //     right: 1.5em;
 //   }
 //   .bb8-toggle__checkbox:hover
 //     + .bb8-toggle__container
 //     .bb8__antenna:nth-child(2) {
 //     left: 0.938em;
 //   }
 //   .bb8-toggle__checkbox:hover + .bb8-toggle__container .bb8__head::after {
 //     background-position: 1.375em 0;
 //   }
 //   .bb8-toggle__checkbox:checked:hover
 //     + .bb8-toggle__container
 //     .bb8__head::before {
 //     left: 0;
 //   }
 //   .bb8-toggle__checkbox:checked:hover
 //     + .bb8-toggle__container
 //     .bb8__antenna:nth-child(2) {
 //     left: calc(100% - 0.938em);
 //   }
 //   .bb8-toggle__checkbox:checked:hover + .bb8-toggle__container .bb8__head::after {
 //     background-position: -1.375em 0;
 //   }
 //   .bb8-toggle__checkbox:active + .bb8-toggle__container .bb8__head-container {
 //     -webkit-transform: rotate(25deg);
 //     -ms-transform: rotate(25deg);
 //     transform: rotate(25deg);
 //   }
 //   .bb8-toggle__checkbox:checked:active
 //     + .bb8-toggle__container
 //     .bb8__head-container {
 //     -webkit-transform: rotate(-25deg);
 //     -ms-transform: rotate(-25deg);
 //     transform: rotate(-25deg);
 //   }
 //   .bb8:hover .bb8__head::before,
 //   .bb8:hover .bb8__antenna:nth-child(2) {
 //     left: 50% !important;
 //   }
 //   .bb8:hover .bb8__antenna:nth-child(1) {
 //     right: 0.938em !important;
 //   }
 //   .bb8:hover .bb8__head::after {
 //     background-position: 0 0 !important;
 //   }`;
 // export default Switch;
}),
"[externals]/module [external] (module, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("module", () => require("module"));

module.exports = mod;
}),
"[project]/components/CoinModel.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CoinModel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$fiber$2f$dist$2f$react$2d$three$2d$fiber$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@react-three/fiber/dist/react-three-fiber.esm.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$fiber$2f$dist$2f$events$2d$f8cd670d$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__D__as__useFrame$3e$__ = __turbopack_context__.i("[project]/node_modules/@react-three/fiber/dist/events-f8cd670d.esm.js [app-ssr] (ecmascript) <export D as useFrame>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$drei$2f$core$2f$OrbitControls$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-three/drei/core/OrbitControls.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$drei$2f$core$2f$Gltf$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-three/drei/core/Gltf.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$drei$2f$core$2f$Environment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-three/drei/core/Environment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$postprocessing$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-three/postprocessing/dist/index.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
function Coin({ isHovered }) {
    const { scene } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$drei$2f$core$2f$Gltf$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useGLTF"])('/models/coin/coin.gltf');
    const meshRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$fiber$2f$dist$2f$events$2d$f8cd670d$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__D__as__useFrame$3e$__["useFrame"])((state)=>{
        if (meshRef.current) {
            const targetY = isHovered ? 0.05 : 0;
            // Smooth lerp for slower movement
            meshRef.current.position.y += (targetY - meshRef.current.position.y) * 0.05;
        }
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("group", {
        ref: meshRef,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("primitive", {
            object: scene,
            scale: 1.5,
            rotation: [
                0,
                0,
                0
            ],
            castShadow: true,
            receiveShadow: true
        }, void 0, false, {
            fileName: "[project]/components/CoinModel.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/CoinModel.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
function CoinModel({ size = 'small' }) {
    const containerClass = size === 'large' ? 'w-64 h-64 lg:w-90 lg:h-90' : 'w-12 h-12';
    const [isHovered, setIsHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${containerClass} relative transition-transform duration-500 ease-in-out ${isHovered ? 'scale-105' : 'scale-100'}`,
        onMouseEnter: ()=>setIsHovered(true),
        onMouseLeave: ()=>setIsHovered(false),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$fiber$2f$dist$2f$react$2d$three$2d$fiber$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Canvas"], {
            camera: {
                position: [
                    0,
                    0,
                    1
                ],
                fov: 45
            },
            gl: {
                antialias: true,
                alpha: true
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Suspense"], {
                fallback: null,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$drei$2f$core$2f$Environment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Environment"], {
                        preset: "studio",
                        background: false,
                        environmentIntensity: 1
                    }, void 0, false, {
                        fileName: "[project]/components/CoinModel.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("directionalLight", {
                        intensity: 1,
                        position: [
                            5,
                            5,
                            5
                        ],
                        castShadow: true
                    }, void 0, false, {
                        fileName: "[project]/components/CoinModel.tsx",
                        lineNumber: 57,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Coin, {
                        isHovered: isHovered
                    }, void 0, false, {
                        fileName: "[project]/components/CoinModel.tsx",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$drei$2f$core$2f$OrbitControls$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["OrbitControls"], {
                        enableZoom: false,
                        enablePan: true,
                        autoRotate: true,
                        autoRotateSpeed: 2,
                        minPolarAngle: Math.PI / 2,
                        maxPolarAngle: Math.PI / 2
                    }, void 0, false, {
                        fileName: "[project]/components/CoinModel.tsx",
                        lineNumber: 67,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$postprocessing$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EffectComposer"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$three$2f$postprocessing$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bloom"], {
                            intensity: 0.001
                        }, void 0, false, {
                            fileName: "[project]/components/CoinModel.tsx",
                            lineNumber: 78,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/CoinModel.tsx",
                        lineNumber: 77,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/CoinModel.tsx",
                lineNumber: 53,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/CoinModel.tsx",
            lineNumber: 48,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/CoinModel.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/HamburgerMenu.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.esm.js [app-ssr] (ecmascript)");
'use client';
;
;
const HamburgerMenu = ({ isOpen, onToggle })=>{
    const handleClick = (e)=>{
        e.preventDefault();
        onToggle();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StyledWrapper, {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: `hamburger ${isOpen ? 'checked' : ''}`,
            onClick: handleClick,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "checkbox",
                    checked: isOpen,
                    onChange: ()=>{},
                    onClick: (e)=>e.stopPropagation()
                }, void 0, false, {
                    fileName: "[project]/components/HamburgerMenu.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    viewBox: "0 0 32 32",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            className: "line line-top-bottom",
                            d: "M27 10 13 10C10.8 10 9 8.2 9 6 9 3.5 10.8 2 13 2 15.2 2 17 3.8 17 6L17 26C17 28.2 18.8 30 21 30 23.2 30 25 28.2 25 26 25 23.8 23.2 22 21 22L7 22"
                        }, void 0, false, {
                            fileName: "[project]/components/HamburgerMenu.tsx",
                            lineNumber: 27,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            className: "line",
                            d: "M7 16 27 16"
                        }, void 0, false, {
                            fileName: "[project]/components/HamburgerMenu.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/HamburgerMenu.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/HamburgerMenu.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/HamburgerMenu.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const StyledWrapper = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].div`
  .hamburger {
    cursor: pointer;
  }

  .hamburger input {
    display: none;
  }

  .hamburger svg {
    /* The size of the SVG defines the overall size */
    height: 3em;
    /* Define the transition for transforming the SVG */
    transition: transform 600ms cubic-bezier(0.4, 0, 0.2, 1);
  }

  .line {
    fill: none;
    stroke: var(--text);
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke-width: 3;
    /* Define the transition for transforming the Stroke */
    transition: stroke-dasharray 600ms cubic-bezier(0.4, 0, 0.2, 1),
                stroke-dashoffset 600ms cubic-bezier(0.4, 0, 0.2, 1);
  }

  .line-top-bottom {
    stroke-dasharray: 12 63;
  }

  .hamburger input:checked + svg,
  .hamburger.checked input + svg {
    transform: rotate(-45deg);
  }

  .hamburger input:checked + svg .line-top-bottom,
  .hamburger.checked input + svg .line-top-bottom {
    stroke-dasharray: 20 300;
    stroke-dashoffset: -32.42;
  }
`;
const __TURBOPACK__default__export__ = HamburgerMenu;
}),
"[project]/components/Navbar.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Navbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAuth.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemeToggle$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ThemeToggle.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CoinModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CoinModel.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HamburgerMenu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/HamburgerMenu.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function Navbar() {
    const { user, loading, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAuth"])();
    const [mobileMenuOpen, setMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: "shadow-md bg-surface",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center h-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: "/",
                            className: "flex items-center gap-2 md:gap-3 text-sm md:text-xl font-bold transition-all duration-300 hover:scale-105 group text-primary",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden md:block transition-transform duration-300 group-hover:rotate-12",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CoinModel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/components/Navbar.tsx",
                                        lineNumber: 24,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/Navbar.tsx",
                                    lineNumber: 23,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "hidden sm:inline relative",
                                    children: [
                                        "Milestone Crowdfunding",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute bottom-0 left-0 w-0 h-0.5 bg-current transition-all duration-300 group-hover:w-full"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 28,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Navbar.tsx",
                                    lineNumber: 26,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "sm:hidden",
                                    children: "MC"
                                }, void 0, false, {
                                    fileName: "[project]/components/Navbar.tsx",
                                    lineNumber: 30,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Navbar.tsx",
                            lineNumber: 19,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "hidden md:flex items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/projects",
                                    className: "relative px-2 py-1 transition-all duration-300 hover:scale-105 group text-text",
                                    children: [
                                        "Projects",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "absolute bottom-0 left-0 w-0 h-0.5 transition-all duration-300 group-hover:w-full bg-primary"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 40,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/Navbar.tsx",
                                    lineNumber: 35,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemeToggle$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/components/Navbar.tsx",
                                    lineNumber: 43,
                                    columnNumber: 13
                                }, this),
                                loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-text opacity-70",
                                    children: "Loading..."
                                }, void 0, false, {
                                    fileName: "[project]/components/Navbar.tsx",
                                    lineNumber: 46,
                                    columnNumber: 15
                                }, this) : user ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        user.is_creator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/dashboard/creator",
                                            className: "relative px-2 py-1 transition-all duration-300 hover:scale-105 group text-text",
                                            children: [
                                                "Creator Dashboard",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute bottom-0 left-0 w-0 h-0.5 transition-all duration-300 group-hover:w-full bg-primary"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Navbar.tsx",
                                                    lineNumber: 55,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 50,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/dashboard/backer",
                                            className: "relative px-2 py-1 transition-all duration-300 hover:scale-105 group text-text",
                                            children: [
                                                "Backer Dashboard",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute bottom-0 left-0 w-0 h-0.5 transition-all duration-300 group-hover:w-full bg-primary"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Navbar.tsx",
                                                    lineNumber: 63,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 58,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "px-2 py-1 transition-all duration-300 hover:scale-110 text-text",
                                            children: user.username
                                        }, void 0, false, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 65,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: logout,
                                            className: "btn-secondary text-sm transition-all duration-300 hover:scale-105 hover:shadow-lg",
                                            children: "Logout"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 66,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/auth/login",
                                            className: "relative px-2 py-1 transition-all duration-300 hover:scale-105 group text-text",
                                            children: [
                                                "Login",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute bottom-0 left-0 w-0 h-0.5 transition-all duration-300 group-hover:w-full bg-primary"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Navbar.tsx",
                                                    lineNumber: 80,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 75,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/auth/register",
                                            className: "btn-primary text-sm transition-all duration-300 hover:scale-105 hover:shadow-lg",
                                            children: "Sign Up"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 82,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Navbar.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "md:hidden flex items-center gap-3",
                            children: [
                                !loading && !user && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/auth/login",
                                            className: "relative px-2 py-1 transition-all duration-300 hover:scale-105 group text-sm text-text",
                                            children: [
                                                "Login",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute bottom-0 left-0 w-0 h-0.5 transition-all duration-300 group-hover:w-full bg-primary"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/Navbar.tsx",
                                                    lineNumber: 102,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 97,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/auth/register",
                                            className: "btn-primary text-xs px-3 py-1.5 transition-all duration-300 hover:scale-105 hover:shadow-lg",
                                            children: "Sign Up"
                                        }, void 0, false, {
                                            fileName: "[project]/components/Navbar.tsx",
                                            lineNumber: 104,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HamburgerMenu$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    isOpen: mobileMenuOpen,
                                    onToggle: ()=>setMobileMenuOpen(!mobileMenuOpen)
                                }, void 0, false, {
                                    fileName: "[project]/components/Navbar.tsx",
                                    lineNumber: 114,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/Navbar.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/Navbar.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `md:hidden border-t overflow-hidden transition-all duration-700 ease-in-out relative border-border ${mobileMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`,
                    children: mobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "py-4 space-y-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/projects",
                                        className: "block px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-md group relative text-text",
                                        onClick: ()=>setMobileMenuOpen(false),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "relative z-10",
                                                children: "Projects"
                                            }, void 0, false, {
                                                fileName: "[project]/components/Navbar.tsx",
                                                lineNumber: 134,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "absolute inset-0 rounded-lg opacity-0 group-hover:opacity-10 transition-opacity duration-300 bg-primary"
                                            }, void 0, false, {
                                                fileName: "[project]/components/Navbar.tsx",
                                                lineNumber: 135,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/Navbar.tsx",
                                        lineNumber: 129,
                                        columnNumber: 17
                                    }, this),
                                    loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-4 text-text opacity-70",
                                        children: "Loading..."
                                    }, void 0, false, {
                                        fileName: "[project]/components/Navbar.tsx",
                                        lineNumber: 139,
                                        columnNumber: 19
                                    }, this) : user ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                        children: [
                                            user.is_creator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/dashboard/creator",
                                                className: "block px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-md group relative text-text",
                                                onClick: ()=>setMobileMenuOpen(false),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "relative z-10",
                                                        children: "Creator Dashboard"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/Navbar.tsx",
                                                        lineNumber: 148,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute inset-0 rounded-lg opacity-0 group-hover:opacity-10 transition-opacity duration-300 bg-primary"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/Navbar.tsx",
                                                        lineNumber: 149,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/Navbar.tsx",
                                                lineNumber: 143,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/dashboard/backer",
                                                className: "block px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-md group relative text-text",
                                                onClick: ()=>setMobileMenuOpen(false),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "relative z-10",
                                                        children: "Backer Dashboard"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/Navbar.tsx",
                                                        lineNumber: 157,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute inset-0 rounded-lg opacity-0 group-hover:opacity-10 transition-opacity duration-300 bg-primary"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/Navbar.tsx",
                                                        lineNumber: 158,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/Navbar.tsx",
                                                lineNumber: 152,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "px-4 py-2 transition-all duration-300 hover:scale-105 text-text",
                                                children: user.username
                                            }, void 0, false, {
                                                fileName: "[project]/components/Navbar.tsx",
                                                lineNumber: 160,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>{
                                                    logout();
                                                    setMobileMenuOpen(false);
                                                },
                                                className: "btn-secondary text-sm mx-4 transition-all duration-300 hover:scale-105 hover:shadow-lg",
                                                children: "Logout"
                                            }, void 0, false, {
                                                fileName: "[project]/components/Navbar.tsx",
                                                lineNumber: 161,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true) : null
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/Navbar.tsx",
                                lineNumber: 128,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute bottom-4 right-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemeToggle$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/components/Navbar.tsx",
                                    lineNumber: 176,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/Navbar.tsx",
                                lineNumber: 175,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                }, void 0, false, {
                    fileName: "[project]/components/Navbar.tsx",
                    lineNumber: 122,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/Navbar.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/Navbar.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__7f45eef0._.js.map