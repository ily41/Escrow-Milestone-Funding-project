module.exports = [
"[project]/.next-internal/server/app/projects/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_projects_%5Bid%5D_page_actions_38fa8475.js.map